Place your legally obtained Android x86_64 image here and set `android_image` in `config.json` to its filename.
