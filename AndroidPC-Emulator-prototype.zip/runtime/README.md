Place runtime-specific notes and optional helper scripts here. Do not commit third-party binaries or Android system images unless you have the rights to redistribute them.
